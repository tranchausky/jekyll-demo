---
name: James Lopez
position: Developer
image_path: https://source.unsplash.com/collection/139386/604x604?a=.png
twitter: CloudCannonApp
blurb: James spends his weekends watching his favourite NBA team - L.A. Clippers.
---
